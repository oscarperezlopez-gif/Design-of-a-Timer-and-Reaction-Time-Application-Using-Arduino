#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "HD44780.hpp"
#include "libADC.hpp"
#include "uart_buffer.hpp"


volatile uint32_t g_ms = 0;

ISR(TIMER0_COMPA_vect) {
  g_ms++;
}

static inline void timer0_init_1ms(void) {
  
  TCCR0A = (1 << WGM01);
  
  TCCR0B = (1 << CS01) | (1 << CS00);
 
  OCR0A = 249;
  
  TIMSK0 = (1 << OCIE0A);
}

static inline uint32_t millis_u32(void) {
  uint32_t t;
  cli();
  t = g_ms;
  sei();
  return t;
}


static inline uint16_t readADC_A0_raw_menuStyle(void)
{
  ADCSRA |= (1 << ADSC);
  while (ADCSRA & (1 << ADSC));
  return ADC; 
}

static inline void waitRelease(void)
{
  uint16_t v;
  do { v = readADC_A0_raw_menuStyle(); } while (v < 900);
  _delay_ms(50);
}


static inline uint8_t isRIGHT(uint16_t v)  { return (v < 100); }
static inline uint8_t isUP(uint16_t v)     { return (v >= 100 && v < 250); }
static inline uint8_t isDOWN(uint16_t v)   { return (v >= 250 && v < 350); }
static inline uint8_t isLEFT(uint16_t v)   { return (v >= 350 && v < 500); }
static inline uint8_t isSELECT(uint16_t v) { return (v >= 500 && v < 850); }


static char buf[17];

static inline void lcd_clear(void) {
  LCD_WriteCommand(HD44780_CLEAR);
  _delay_ms(5);
}

static inline void lcd_print2(const char* l1, const char* l2) {
  lcd_clear();
  LCD_GoTo(1,1); LCD_WriteText((uint8_t*)l1);
  LCD_GoTo(1,2); LCD_WriteText((uint8_t*)l2);
}


enum AppState { ST_MENU, ST_STOPWATCH, ST_REACT_IDLE, ST_REACT_WAIT, ST_REACT_GO, ST_REACT_RES, ST_REACT_BEST };
static AppState state = ST_MENU;

static uint8_t menuPos = 1;     
static uint8_t refreshLCD = 1;  

// Stopwatch
static uint8_t sw_running = 0;
static uint32_t sw_start_ms = 0;
static uint32_t sw_elapsed_ms = 0;

// Reaction
static uint32_t wait_start = 0;
static uint32_t wait_duration = 0;
static uint32_t go_time = 0;
static uint32_t last_rt = 0;
static uint32_t best_rt = 0xFFFFFFFF;


static void format_stopwatch(char* out16, uint32_t ms) {
  uint32_t sec = ms / 1000;
  uint32_t min = sec / 60;
  sec = sec % 60;
  uint32_t cs = (ms % 1000) / 10; 
  
  sprintf(out16, "%02lu:%02lu.%02lu",
          (unsigned long)min, (unsigned long)sec, (unsigned long)cs);
}


static void show_menu(void) {
  lcd_clear();
  LCD_GoTo(1,1);
  sprintf(buf, "[%u]", (unsigned)menuPos);
  LCD_WriteText((uint8_t*)buf);

  LCD_GoTo(1,2);
  if (menuPos == 1) LCD_WriteText((uint8_t*)"Stopwatch");
  else              LCD_WriteText((uint8_t*)"Reaction Game");

  refreshLCD = 0;
}

static void show_stopwatch(void) {
  lcd_print2("STOPWATCH", "00:00.00");
}

static void show_react_idle(void) {
  lcd_print2("REACTION", "SEL=start UP=best");
}

static void show_react_wait(void) {
  lcd_print2("REACTION", "WAIT...");
}

static void show_react_go(void) {
  lcd_print2("REACTION", "GO! press SELECT");
}

static void show_react_res(void) {
  lcd_clear();
  LCD_GoTo(1,1); LCD_WriteText((uint8_t*)"RESULT");
  LCD_GoTo(1,2);
  sprintf(buf, "RT:%lums", (unsigned long)last_rt);
  LCD_WriteText((uint8_t*)buf);
}

static void show_react_best(void) {
  lcd_clear();
  LCD_GoTo(1,1); LCD_WriteText((uint8_t*)"BEST");
  LCD_GoTo(1,2);
  if (best_rt == 0xFFFFFFFF) {
    LCD_WriteText((uint8_t*)"No record yet");
  } else {
    sprintf(buf, "%lums", (unsigned long)best_rt);
    LCD_WriteText((uint8_t*)buf);
  }
}


int main(void)
{
  LCD_Initalize();
  uart_init(9600, 0);
  ADC_Init();

  timer0_init_1ms();
  sei();

  
  srand(readADC_A0_raw_menuStyle());

 
  uint32_t t0 = millis_u32();
  while (millis_u32() - t0 < 600) {
    (void)readADC_A0_raw_menuStyle();
    _delay_ms(10);
  }
  waitRelease();

  
  state = ST_MENU;
  refreshLCD = 1;

  while (1)
  {
    uint16_t raw = readADC_A0_raw_menuStyle();

    
    if (state == ST_MENU) {
      if (isUP(raw) && menuPos > 1) {
        menuPos--;
        refreshLCD = 1;
        waitRelease();
      }
      if (isDOWN(raw) && menuPos < 2) {
        menuPos++;
        refreshLCD = 1;
        waitRelease();
      }
      if (refreshLCD) show_menu();

      if (isRIGHT(raw)) {
        waitRelease();
        if (menuPos == 1) {
          state = ST_STOPWATCH;
          sw_running = 0;
          sw_elapsed_ms = 0;
          show_stopwatch();
        } else {
          state = ST_REACT_IDLE;
          show_react_idle();
        }
      }
    }

    
    else if (state == ST_STOPWATCH) {
      
      if (isLEFT(raw)) {
        waitRelease();
        state = ST_MENU;
        refreshLCD = 1;
      }

      
      if (isSELECT(raw)) {
        waitRelease();
        if (!sw_running) {
          sw_running = 1;
          sw_start_ms = millis_u32() - sw_elapsed_ms; 
        } else {
          sw_running = 0;
          sw_elapsed_ms = millis_u32() - sw_start_ms;
        }
      }

      
      if (isRIGHT(raw) && !sw_running) {
        waitRelease();
        sw_elapsed_ms = 0;
        
        LCD_GoTo(1,2);
        LCD_WriteText((uint8_t*)"00:00.00        ");
      }

      
      uint32_t t = sw_running ? (millis_u32() - sw_start_ms) : sw_elapsed_ms;
      char tbuf[17];
      format_stopwatch(tbuf, t);
      LCD_GoTo(1,2);
     
      sprintf(buf, "%s        ", tbuf);
      LCD_WriteText((uint8_t*)buf);

      _delay_ms(80);
    }

    
    else if (state == ST_REACT_IDLE) {
      if (isLEFT(raw)) { waitRelease(); state = ST_MENU; refreshLCD = 1; }
      if (isUP(raw))   { waitRelease(); state = ST_REACT_BEST; show_react_best(); }
      if (isSELECT(raw)) {
        waitRelease();
        state = ST_REACT_WAIT;
        wait_start = millis_u32();
        wait_duration = 1000 + (rand() % 3001); 
        show_react_wait();
      }
      _delay_ms(60);
    }

    
    else if (state == ST_REACT_WAIT) {
      if (isLEFT(raw)) { waitRelease(); state = ST_MENU; refreshLCD = 1; }

      
      if (isSELECT(raw)) {
        
        if (millis_u32() - wait_start < wait_duration) {
          waitRelease();
          lcd_print2("TOO SOON!", "SEL=retry UP=best");
          last_rt = 0;
          state = ST_REACT_RES;
        }
      }

      if (millis_u32() - wait_start >= wait_duration) {
        state = ST_REACT_GO;
        go_time = millis_u32();
        show_react_go();
      }
      _delay_ms(20);
    }

    
    else if (state == ST_REACT_GO) {
      if (isLEFT(raw)) { waitRelease(); state = ST_MENU; refreshLCD = 1; }

      if (isSELECT(raw)) {
        waitRelease();
        last_rt = millis_u32() - go_time;
        if (last_rt < best_rt) best_rt = last_rt;
        show_react_res();
        state = ST_REACT_RES;
      }
      _delay_ms(15);
    }

    
    else if (state == ST_REACT_RES) {
      if (isLEFT(raw)) { waitRelease(); state = ST_MENU; refreshLCD = 1; }
      if (isUP(raw))   { waitRelease(); state = ST_REACT_BEST; show_react_best(); }
      if (isSELECT(raw)) { waitRelease(); state = ST_REACT_IDLE; show_react_idle(); }
      _delay_ms(60);
    }

    
    else if (state == ST_REACT_BEST) {
      if (isLEFT(raw)) { waitRelease(); state = ST_MENU; refreshLCD = 1; }
      if (isSELECT(raw)) { waitRelease(); state = ST_REACT_IDLE; show_react_idle(); }
      _delay_ms(80);
    }
  }
}
