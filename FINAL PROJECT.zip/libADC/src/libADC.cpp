#include "libADC.hpp"

void ADC_Init(void){
ADCSRA |= (1 << ADEN);

ADCSRA |= (1 << ADPS0);
ADCSRA |= (1 << ADPS1);
ADCSRA |= (1 << ADPS2);

ADMUX &= ~ (1 << REFS1);
ADMUX |= (1 << REFS0);

ADMUX &= ~(1 << ADLAR);

ADMUX &= 0xF0;
}

int ADC_conversion(void){
ADCSRA = (1 << ADSC);
while (ADCSRA & (1 << ADSC)) {}
return ADC;
}